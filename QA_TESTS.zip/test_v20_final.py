"""Adversarial tests; ALL generated price/performance fixtures are synthetic."""
from copy import deepcopy
from dataclasses import replace, asdict
from pathlib import Path
import json, zipfile
import numpy as np
import pandas as pd
import pytest
from v19_config import Settings
from v20_final import (PROTOCOL, PROTOCOL_VERSION, protocol_hash, protocol_manifest,
    policy_record, allocation_decision, comparable, global_disjoint, stats,
    clean_case, summarize_final, write_final_bundle, benchmark_record)
from v20_model import rank_v202_day, v202_market_state, add_v202_factors
from v19_backtest import preselected_result


def day_fixture():
    rows=[]
    for i in range(9):
        row=dict(date=pd.Timestamp('2025-01-02'),ticker='0050.TW' if i==0 else f'{2100+i}.TW',
            name=str(i),eligible=i>0,close=100.,p197_liquidity=100.-i*4,
            p197_annual_high=95.-i*3,p197_downside=70.,p197_trend_eff=70.,
            p202_rel20=70.,p202_rel5=70.,p202_volume_impulse=70.,p202_entry_quality=70.,
            bias20=2.,rsi=60.,regime='NEUTRAL',p197_market_breadth=.6,p197_market_gate='NEUTRAL',
            source='SYNTHETIC_TEST_ONLY')
        for h in (5,20,60):
            row.update({f'net_{h}':.01*i,f'mae_{h}':-.02,f'mdd_{h}':-.03,
                f'outcome_state_{h}':'ASSUMED_OPEN_FILL',f'return_basis_{h}':'ADJUSTED_PROVIDER',
                f'path_complete_{h}':True})
        rows.append(row)
    return pd.DataFrame(rows)


@pytest.mark.parametrize('future', [None, -.8, 0., .5])
def test_future_outcome_never_changes_policy_state(future):
    cr=dict(selected=5,complete=future is not None,mean_net=future,price_basis='ADJUSTED_PROVIDER')
    bm=dict(selected=1,complete=True,mean_net=.03,price_basis='ADJUSTED_PROVIDER')
    p=policy_record(cr,'STOCK_SELECTION',bm)
    assert p['v202_policy_state']=='STOCK_SELECTION'
    assert p['mean_net']==future
    assert p['complete']==(future is not None)
    assert not p['decision_uses_future_outcomes']


def test_unknown_context_is_not_stock_allocation():
    assert v202_market_state(pd.DataFrame({'eligible':[True],'ticker':['2330.TW']}))=='UNKNOWN'
    assert allocation_decision('UNKNOWN',5)=='UNKNOWN'
    assert policy_record({'selected':5},'UNKNOWN',{})['mean_net'] is None


@pytest.mark.parametrize('h',[5,20,60])
def test_clean_case_uses_identical_core_ranking_to_live(h):
    day=day_fixture();cfg=Settings(top_k=5)
    out=clean_case(day,day.date.iloc[0],h,cfg)
    actual=[x['ticker'] for x in out['trades'] if x['strategy']=='v202_core_cascade']
    assert actual==rank_v202_day(day,h,cfg).ticker.tolist()
    assert out['fit']['status']=='FINAL_FIXED_NO_REFIT'


def test_gate_removes_core_without_promoting_lower_rank():
    day=day_fixture();day.loc[day.ticker=='2101.TW',['p202_rel20','p197_downside','p197_trend_eff']]=0.
    sixty=rank_v202_day(day,60,Settings())
    twenty=rank_v202_day(day,20,Settings())
    assert len(sixty)==5 and len(twenty)==4
    assert set(twenty.ticker)<set(sixty.ticker)
    assert '2106.TW' not in set(twenty.ticker)


def test_future_nan_does_not_change_selected_tickers():
    day=day_fixture();cfg=Settings()
    a=rank_v202_day(day,20,cfg).ticker.tolist()
    day.loc[day.ticker.isin(a),'net_20']=np.nan
    b=rank_v202_day(day,20,cfg).ticker.tolist()
    assert a==b
    payload=clean_case(day,day.date.iloc[0],20,cfg)
    policy=next(x for x in payload['records'] if x['strategy']=='v202_policy')
    assert policy['mean_net'] is None and policy['v202_policy_state']=='STOCK_SELECTION'


def test_partial_selection_cash_slots_do_not_use_selected_mean():
    q=day_fixture().query('eligible').head(2)
    r,_=preselected_result(q,q.date.iloc[0],20,Settings(),'test')
    assert r['complete'] and r['cash_slots']==3
    assert r['mean_net']==pytest.approx((.01+.02)/5)
    q.loc[q.index[0],'net_20']=np.nan
    missing,_=preselected_result(q,q.date.iloc[0],20,Settings(),'test')
    assert not missing['complete'] and missing['mean_net'] is None


def test_empty_or_known_unfilled_slots_are_cash_not_missing():
    q=day_fixture().query('eligible').head(0)
    r,_=preselected_result(q,'2025-01-02',20,Settings(),'test')
    assert r['complete'] and r['mean_net']==0 and r['price_basis']=='CASH'
    q=day_fixture().query('eligible').head(1).copy()
    q['net_20']=0.;q['return_basis_20']='CASH';q['outcome_state_20']='NO_VOLUME'
    r,_=preselected_result(q,'2025-01-02',20,Settings(),'test')
    assert r['complete'] and r['price_basis']=='CASH'


def test_suspended_benchmark_is_not_zero_return_reference():
    day=day_fixture();day.loc[~day.eligible,'outcome_state_60']='NO_VOLUME'
    day.loc[~day.eligible,'net_60']=0.
    b=benchmark_record(day,'2025-01-02',60,Settings())
    assert not b['complete'] and b['mean_net'] is None


@pytest.mark.parametrize('left,right',[('RAW_PRICE_ONLY','ADJUSTED_PROVIDER'),('MIXED_UNVERIFIED','ADJUSTED_PROVIDER'),('UNKNOWN','UNKNOWN')])
def test_unknown_or_raw_price_bases_do_not_authorize_alpha(left,right):
    assert not comparable(dict(complete=True,mean_net=.1,price_basis=left),dict(complete=True,mean_net=.05,price_basis=right))


def test_global_disjoint_is_not_union_of_separate_wave_subsets():
    cal=[str(d.date()) for d in pd.bdate_range('2024-01-02',periods=400)]
    reps=[dict(settings={'research_stage':'C1'},calendar_dates=cal,cutoffs=[cal[x] for x in [100,170,240]]),
          dict(settings={'research_stage':'C2'},calendar_dates=cal,cutoffs=[cal[x] for x in [101,171,241]])]
    assert len(global_disjoint(reps,60))==3
    reps[0]['results']=[{'mean_net':None}]
    assert len(global_disjoint(reps,60))==3  # never cherry-pick using future availability


def test_single_nonoverlap_observation_has_no_fake_confidence_interval():
    s=stats([('C1','2025-01-02',.2,1)],{('C1','2025-01-02')},reps=1000)
    assert s['disjoint_bootstrap_95_low'] is None


def healthy_reports(policy_value=.09):
    cal=[str(x.date()) for x in pd.bdate_range('2022-01-03',periods=1250)]
    reports=[]
    for n,w in enumerate(PROTOCOL['wave_plan']):
        ds=[cal[100+i*12+n*6] for i in range(48)]
        rows=[]
        for d in ds:
            for h in (5,20,60):
                for name,val in [('v202_core_cascade',.09),('equal_weight_universe',.02),
                     ('benchmark_0050',.03),('v202_policy',policy_value),
                     ('v203_no_gates',.09),('v203_confirm_only',.09),('v203_full_gates',.09)]:
                    rows.append(dict(date=d,horizon=h,strategy=name,mean_net=val,complete=True,
                         price_basis='ADJUSTED_PROVIDER',selected=5,slots=5,filled=5,
                         v202_policy_state='STOCK_SELECTION'))
        settings=dict(w,research_stage=w['key'],top_k=5,horizons=[5,20,60],excluded_cutoffs=[])
        reports.append(dict(version=PROTOCOL_VERSION,settings=settings,results=rows,cutoffs=ds,
            final_protocol_hash=protocol_hash(),final_code_hash='SYNTHETIC_TEST_FIXTURE',
            data_kind='PROVIDER_HISTORY',calendar_dates=cal,execution_status='STAGE_COMPLETE',
            manifest={'scope':'V202_TWSE_TPEX_OFFICIAL_CURRENT_TEST',
               'universe_quality':{'catalog_fingerprint':'FIXTURE','download_coverage':1.}}))
    return reports


def test_acceptance_requires_policy_and_selection_not_just_selection():
    good=summarize_final(healthy_reports(),reps=1000)
    assert good['core_verdict']=='PASSED_HISTORICAL_RESEARCH_ONLY'
    bad=summarize_final(healthy_reports(policy_value=.01),reps=1000)
    assert bad['core_verdict']=='NOT_PASSED'
    h=next(x for x in bad['horizons'] if x['horizon']==60)
    assert h['acceptance']['selection_vs_same_pool']['status']=='PASSED_HISTORICAL_RESEARCH_ONLY'
    assert h['acceptance']['policy_vs_0050']['status']=='NOT_PASSED'
    assert bad['full_original_goal']=='NOT_CERTIFIED' and not bad['automatic_weight_adoption']


@pytest.mark.parametrize('change,expected',[
 ('synthetic','NOT_REAL_PROVIDER_HISTORY'),('duplicate','DUPLICATE_RESULT_ROWS'),
 ('version','WRONG_ENGINE_VERSION'),('weights','PROTOCOL_NOT_MATCHED'),
 ('roster','ROSTER_CHANGED_BETWEEN_WAVES'),('seed','WAVE_SETTINGS_NOT_MATCHED')])
def test_fail_closed_integrity_cases(change,expected):
    reports=healthy_reports()
    if change=='synthetic': reports[0]['data_kind']='SYNTHETIC_TEST_ONLY'
    elif change=='duplicate': reports[0]['results'].append(reports[0]['results'][0])
    elif change=='version': reports[0]['version']='20.2.1'
    elif change=='weights': reports[0]['final_protocol_hash']='OTHER'
    elif change=='roster': reports[0]['manifest']['universe_quality']['catalog_fingerprint']='CHANGED'
    elif change=='seed': reports[0]['settings']['seed']=1
    s=summarize_final(reports,reps=1000)
    assert expected in s['integrity_issues'] and s['core_verdict']=='INSUFFICIENT_EVIDENCE'


def test_missing_results_not_replaced_with_zero_or_omitted_without_warning():
    reports=healthy_reports()
    for r in reports[0]['results']:
        if r['strategy']=='v202_core_cascade':r['mean_net']=None;r['complete']=False
    s=summarize_final(reports,reps=1000)
    assert s['core_verdict']=='INSUFFICIENT_EVIDENCE'


@pytest.mark.parametrize('module',['v20_model.py','v195_selection.py','v19_service.py'])
def test_core_module_edit_changes_checkpoint_hash(tmp_path,monkeypatch,module):
    import v192_checkpoint as ck
    # Fake only module path, copy all hashed modules; do not modify the live code.
    root=Path(ck.__file__).parent
    import shutil
    for p in root.glob('*.py'):shutil.copyfile(p,tmp_path/p.name)
    monkeypatch.setattr(ck,'__file__',str(tmp_path/'v192_checkpoint.py'))
    before=ck.code_digest()
    target=tmp_path/module;target.write_text(target.read_text()+'\n# test change\n')
    assert before!=ck.code_digest()


def test_pause_request_survives_progress_update(tmp_path):
    import v19_service as svc
    from v19_data import atomic_json,read_json
    atomic_json(svc._auto_path(tmp_path),{'stop_requested':True})
    state={'state':'RUNNING','stop_requested':False}
    svc._auto_write(tmp_path,state,phase='RUN')
    assert read_json(svc._auto_path(tmp_path))['stop_requested']


def test_finished_campaign_cannot_restart_until_pass(tmp_path):
    import v19_service as svc
    from v19_data import atomic_json
    atomic_json(svc._auto_path(tmp_path),{'version':PROTOCOL_VERSION,'state':'DONE'})
    assert svc.start_auto_campaign(tmp_path,Settings(),resume=False)['state']=='FINAL_ALREADY_FINISHED'


def test_final_bundle_is_reproducible_and_explicitly_not_full_certification(tmp_path):
    reports=healthy_reports();s=summarize_final(reports,reps=1000)
    path=write_final_bundle(tmp_path,reports,s,protocol_manifest())
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
        assert len(z.namelist())==len(set(z.namelist()))
        assert 'C1_DECISIONS.json' in z.namelist() and 'FINAL_PROTOCOL.json' in z.namelist()
        final=json.loads(z.read('FINAL_RESULTS.json'))
        assert final['full_original_goal']=='NOT_CERTIFIED'
    # Re-export must not include a stale SHA256.json twice or hash itself.
    write_final_bundle(tmp_path,reports,s,protocol_manifest())
    with zipfile.ZipFile(path) as z:
        assert len(z.namelist())==len(set(z.namelist()))


def test_benchmark_subtraction_does_not_make_rank_beta_adjusted():
    # Important interpretation check: within a date these rankings are identical.
    a=pd.Series([.02,.1,-.08,.04]); bm=.06
    pd.testing.assert_series_equal(a.rank(pct=True),(a-bm).rank(pct=True))


def test_breadth_uses_consistent_price_units():
    from v197_ten_pillars import add_pillars
    p=[]
    for ticker in ['2101.TW','2102.TW','2103.TW']:
        for d in pd.bdate_range('2024-01-01',periods=260):
            p.append(dict(date=d,ticker=ticker,calc_close=100.,calc_high=101.,calc_low=99.,
              close=25.,ma60=26.,eligible=True,turnover20=1e8,regime='NEUTRAL',
              ret60=0.,ret20=0.,sector='A',share_volume=1e6, p197_sector=np.nan,downside_vol60=.02,trend_efficiency=50.,
              squeeze_release=50.,relative_strength=50.,foreign=np.nan,trust=np.nan,revenue=np.nan,quality=np.nan))
    f=add_pillars(pd.DataFrame(p),Settings(min_universe=3,top_k=3))
    assert f.p197_market_breadth.iloc[-1]==0.


def test_final_annual_high_requires_full_252_bars_not_180():
    from v197_ten_pillars import add_pillars
    cal=pd.bdate_range('2024-01-02',periods=260)
    p=[]
    for i in range(12):
        c=np.linspace(100,130,len(cal))
        p.append(pd.DataFrame(dict(date=cal,ticker=f'{1100+i}.TW',calc_close=c,
            calc_high=c*1.01,calc_low=c*.99,close=c,share_volume=1e6,
            turnover20=3e7,eligible=True,ma60=c*.98,regime='NEUTRAL',
            ret20=.02,ret60=.05,sector='A')))
    out=add_pillars(pd.concat(p,ignore_index=True),Settings(research_stage='C1'))
    assert out.loc[out.date==cal[250],'p197_annual_high'].isna().all()
    assert out.loc[out.date==cal[251],'p197_annual_high'].notna().all()


def test_same_pool_uses_rankable_at_t_not_future_outcome_availability():
    day=day_fixture();day.loc[day.ticker=='2108.TW','p197_annual_high']=np.nan
    out=clean_case(day,day.date.iloc[0],60,Settings())
    pool=next(r for r in out['records'] if r['strategy']=='equal_weight_universe')
    assert pool['selected']==7
    day.loc[day.ticker=='2107.TW','net_60']=np.nan
    out=clean_case(day,day.date.iloc[0],60,Settings())
    pool=next(r for r in out['records'] if r['strategy']=='equal_weight_universe')
    assert pool['selected']==7 and not pool['complete']
