"""V19.8 tests: source market population, bias warnings and factor masks.
All synthetic fixtures are engineering tests, not investment backtests.
"""
from dataclasses import replace
import json
import time
from pathlib import Path
import numpy as np
import pandas as pd
import pytest
from v19_config import VERSION,Settings
from v198_universe import normalize_catalog,balanced_sample,summarize_catalog,market,historical_pool_diagnostics
import requests
from v198_selection import profiles_for_v198
from v19_data import Client,SourceError,atomic_json,download_history
from v19_service import load_inputs


def catalog(count=1800):
    data=[]
    for i in range(count):
        data.append({'ticker':f'{1000+i}.TW' if i%3 else f'{1000+i}.TWO',
                     'name':str(i),'sector':['電子工業','生技醫療','紡織','金融','食品','光電','營建','航運','其他'][i%9]})
    return data


def test_new_settings_are_not_old_limited_pool():
    c=Settings()
    assert VERSION=='20.3-final' and c.stocks==600 and c.dates==100
    assert c.factor_design=='balanced_v198' and c.universe_mode=='balanced'
    assert c.min_download_coverage==.8


@pytest.mark.parametrize('mode',['balanced','proportional','legacy_random','full_current'])
def test_sampling_unique_deterministic_independent_date_seed(mode):
    src=catalog()
    a=balanced_sample(src,600,seed=82,mode=mode)
    b=balanced_sample(src[::-1],600,seed=82,mode=mode)
    assert a==b
    assert len({r['ticker'] for r in a})==len(a)
    assert len(a)==(1800 if mode=='full_current' else 600)
    assert {x['board'] for x in a}=={'TWSE','TPEX'}


def test_small_sectors_maintained_when_n_enough():
    src=catalog(700)
    a=balanced_sample(src,300,42,'balanced')
    assert len(set((x['board'],x['sector']) for x in a))==len(set((x['board'],x['sector']) for x in normalize_catalog(src)))
    assert len(set(x['sector'] for x in a))>=8
    assert len(set(x['ticker'] for x in a))==300


def test_modes_are_not_identical_in_diverse_catalog():
    src=catalog()
    assert {r['ticker'] for r in balanced_sample(src,300,42,'balanced')} != {r['ticker'] for r in balanced_sample(src,300,42,'legacy_random')}


def test_no_ETF_or_duplicate_or_invalid():
    rows=catalog(2)+[{'ticker':'0050.TW','sector':'ETF'},
                     {'ticker':'1234.TW','sector':'ETF'},
                     {'ticker':'q234.TW','sector':'food'},
                     {'ticker':'1000.TWO','sector':'extra'}]
    x=normalize_catalog(rows)
    assert len(x)==2 and x[0]['ticker']=='1000.TWO'


def test_coverage_ledgers_separate_catalog_selection_and_download():
    src=catalog(800)
    selected=balanced_sample(src,400,42)
    ok=[r['ticker'] for r in selected[:210]]
    q=summarize_catalog(src,selected,ok)
    assert q['catalog_size']==800 and q['selected_size']==400 and q['downloaded_size']==210
    assert q['download_coverage']==pytest.approx(.525)
    assert len(q['missing_selected'])==190
    assert not q['historical_listing_delisting_verified']
    assert not q['diversity_is_not_accuracy_or_market_cap_representativeness'] is False


def test_universe_from_cached_current_master_large(tmp_path):
    rows=catalog()
    atomic_json(tmp_path/'universe.json',{'at':time.time(),'rows':rows,'scope':'CACHED_CURRENT_SNAPSHOT'})
    c=Client(tmp_path,Settings(stocks=600,universe_mode='balanced'))
    selected,scope=c.universe()
    assert len(selected)==600 and scope=='CACHED_CURRENT_SNAPSHOT'
    assert (tmp_path/'universe_quality.json').exists()
    assert (tmp_path/'selected_universe.csv').exists()
    q=json.loads((tmp_path/'universe_quality.json').read_text())
    assert q['catalog_size']==1800 and q['selected_market']['TWSE']>0 and q['selected_market']['TPEX']>0


def test_discovery_failure_wont_claim_54_stock_full_market(tmp_path):
    def no_network(*a,**k):raise requests.ConnectionError('OFFLINE')
    c=Client(tmp_path,Settings(stocks=600),transport=no_network)
    with pytest.raises(SourceError,match='BROAD_UNIVERSE_CATALOG_UNAVAILABLE'):c.universe()


def test_legacy_fallback_requires_explicit_mode(tmp_path):
    def no_network(*a,**k):raise requests.ConnectionError('OFFLINE')
    cfg=Settings(universe_mode='legacy_random')
    q,scope=Client(tmp_path,cfg,transport=no_network).universe()
    assert 40<=len(q)<=60 and 'LEGACY' in scope


def test_supplied_delisted_symbols_append_without_certification(tmp_path):
    src=catalog(100)
    atomic_json(tmp_path/'universe.json',{'at':time.time(),'rows':src,'scope':'CACHED_CURRENT_SNAPSHOT'})
    (tmp_path/'historical_universe.csv').write_text('ticker,name,sector,listed_date,delisted_date,source\n5201.TWO,delisted,電子,2022-01-01,2024-12-31,EXAMPLE_IMPORT\n')
    c=Client(tmp_path,Settings(stocks=300))
    pool,scope=c.universe()
    assert '5201.TWO' in {r['ticker'] for r in pool}
    assert 'UNVERIFIED' in scope
    x=next(r for r in pool if r['ticker']=='5201.TWO')
    assert x['delisted_date']=='2024-12-31'


def test_profile_weights_are_small_family_and_sum_one():
    for h in (5,20,60):
        p=profiles_for_v198(h)
        assert p['legacy_control']
        assert len(p)>=5
        for k,w in p.items():
            assert sum(w.values())==pytest.approx(1.)
            if k!='legacy_control':assert 1<=len(w)<=3
        assert all('p197_sector' not in w for w in p.values())
    p=profiles_for_v198(5)
    assert p['high_defense_65_35']=={'p197_annual_high':.65,'p197_downside':.35}


def test_no_optional_financial_factor_without_evidence():
    assert all('p197_quality' not in w for w in profiles_for_v198(60,Settings(optional_data=False)).values())
    assert 'quality_liquid_research' in profiles_for_v198(60,Settings(optional_data=True))


def test_loading_cache_does_not_fabricate_600_stock_pool(tmp_path):
    dates=pd.bdate_range('2025-01-01',periods=30)
    frame=pd.concat([pd.DataFrame({'date':dates,'ticker':f'{1100+i}.TW','open':10+i,
      'close':10+i,'high':10+i,'low':10+i,'volume':1000000,'source':'SYNTHETIC_TEST_ONLY'}) for i in range(25)],ignore_index=True)
    frame.to_csv(tmp_path/'history_prices.csv.gz',index=False,compression='gzip')
    prices,_=load_inputs(tmp_path,Settings(stocks=600,as_of='2025-03-31'))
    assert prices.ticker.nunique()==25


def test_quartiles_are_historical_signal_date_only():
    d=pd.Timestamp('2025-01-02')
    p=pd.DataFrame({'date':[d]*24,'ticker':[f'{1000+i}.TW' if i%2 else f'{1000+i}.TWO' for i in range(24)],
                    'eligible':[True]*24,'turnover20':np.arange(1,25,dtype=float)*1e6,'sector':['dummy']*24})
    q=historical_pool_diagnostics(p,Settings(stocks=600,as_of='2025-01-06'))
    assert q['tested_tickers']==24 and q['today_eligible']==24
    assert q['tested_market']=={'TPEX':12,'TWSE':12}
    assert q['liquidity_proxy_quartiles_ntd']['0.5']==pytest.approx(12.5e6)


def test_backward_compat_legacy_stays_unchanged():
    from v197_selection import profiles_for
    old=profiles_for(5,Settings(factor_design='ten_angle_v197'))
    new=profiles_for(5,Settings(factor_design='balanced_v198'))
    assert 'sector_leadership_RESEARCH_ONLY' in old
    assert 'sector_leadership_RESEARCH_ONLY' not in new
    assert 'high_defense_65_35' not in old


def test_offline_sourced_catalog_can_supply_broad_universe_without_network(tmp_path):
    def no_network(*a,**k):raise requests.ConnectionError('OFFLINE')
    source=catalog(800)
    df=pd.DataFrame(source)
    df['source']='USER_DOCUMENTED_SNAPSHOT'
    df.to_csv(tmp_path/'historical_universe.csv',index=False)
    c=Client(tmp_path,Settings(stocks=600),transport=no_network)
    pool,scope=c.universe()
    assert len(pool)==600 and 'USER_SUPPLIED' in scope and 'UNVERIFIED' in scope
    assert (tmp_path/'universe_quality.json').exists()
    assert not c.universe_quality['historical_listing_delisting_verified']


def test_downloaded_count_is_not_equivalent_to_factor_history(tmp_path):
    from v198_universe import history_depth_report
    selected=catalog(4)
    ticks=[x['ticker'] for x in selected]
    frames=[]
    for ticker,n in zip(ticks,[2,79,80,260]):
        frames.append(pd.DataFrame({'ticker':ticker,'date':pd.bdate_range('2025-01-01',periods=n)}))
    q=history_depth_report(pd.concat(frames,ignore_index=True),selected,warmup=80)
    assert q['downloaded_price_symbols']==4
    assert q['warmup_eligible_symbols']==2
    assert q['warmup_eligible_fraction']==.5
    assert q['has_252_bar_history_symbols']==1


def test_sourced_listing_dates_propagate_into_history_and_eligibility(tmp_path,monkeypatch):
    from v19_features import build_panel
    from v19_data import COLS
    source=catalog(5)
    source[0].update(listed_date='2024-01-01',delisted_date='2024-12-31',member_source='DATED_USER_SOURCE')
    atomic_json(tmp_path/'universe.json',{'at':time.time(),'rows':source,'scope':'USER_DOCUMENTED_CURRENT'})
    def fake_prices(self,ticker,start,end,official_fallback=False,force=False):
        dates=pd.bdate_range('2024-03-01',periods=170)
        close=np.linspace(10,25,len(dates))
        f=pd.DataFrame({'date':dates,'ticker':ticker,'open':close,'high':close*1.01,
            'low':close*.99,'close':close,'volume':5000000,
            'adj_close':close,'source':'MOCK_PRICE_NOT_MARKET'})
        return f,{'ticker':ticker,'state':'FETCHED','rows':len(f)}
    monkeypatch.setattr(Client,'prices',fake_prices)
    cfg=Settings(stocks=5,years=3,as_of='2026-10-15',optional_data=False)
    prices,ev,manifest=download_history(tmp_path,cfg)
    x=prices[prices.ticker==source[0]['ticker']]
    assert set(x['delisted_date'])=={'2024-12-31'}
    assert set(x['member_source'])=={'DATED_USER_SOURCE'}
    assert manifest['universe_quality']['has_252_bar_history_symbols']==0
    assert len(pd.read_csv(tmp_path/'history_prices.csv.gz'))>0
    # Real metadata reaches the eligibility filter: a post-delisting bar is ineligible.
    later=pd.concat([x,pd.DataFrame([dict(x.iloc[-1],date=pd.Timestamp('2025-03-03'))])],ignore_index=True)
    # Already dated metadata is not erased by the price cleaning stage.
    assert set(later['delisted_date'])=={'2024-12-31'}


def test_small_catalog_cannot_masquerade_as_large_target(tmp_path,monkeypatch):
    from v19_data import download_history
    rows=catalog(5)
    atomic_json(tmp_path/'universe.json',{'at':time.time(),'rows':rows,'scope':'CACHED_STOCK_MASTER'})
    def fake_prices(self,ticker,start,end,official_fallback=False,force=False):
        dates=pd.bdate_range('2025-01-01',periods=100)
        vals=np.linspace(10,20,len(dates))
        x=pd.DataFrame({'date':dates,'ticker':ticker,'open':vals,'high':vals*1.01,
          'low':vals*.99,'close':vals,'volume':1000000,'adj_close':vals,'source':'MOCK'})
        return x,{'ticker':ticker,'state':'FETCHED','rows':len(x)}
    monkeypatch.setattr(Client,'prices',fake_prices)
    _,_,m=download_history(tmp_path,Settings(stocks=600,as_of='2026-10-15'))
    assert m['pool_equities']==5 and m['ready_equities']==5
    assert m['download_completeness']==1.
    assert m['requested_target_coverage']<.01
    assert m['catalog_target_coverage']<.01

# V19.8.1: executable Cloud safe-start and repeatable validation checks.
def test_safe_boot_has_no_heavy_model_import(monkeypatch):
    import importlib.util
    import sys
    import types
    import app
    events=[]
    class Block:
        def __enter__(self): return self
        def __exit__(self, *args): return False
    class FakeStreamlit(types.SimpleNamespace):
        def set_page_config(self, **kw): events.append('set_page_config')
        def title(self, *a, **kw): events.append('title')
        def success(self, *a, **kw): pass
        def info(self, *a, **kw): pass
        def caption(self, *a, **kw): pass
        def button(self, *a, **kw): return False
        def expander(self, *a, **kw): return Block()
        def write(self, *a, **kw): pass
    fake=FakeStreamlit(session_state={})
    monkeypatch.setitem(sys.modules,'streamlit',fake)
    monkeypatch.delitem(sys.modules,'v19_ui',raising=False)
    app.run()
    assert events==['set_page_config','title']
    assert 'v19_ui' not in sys.modules


def test_full_boot_traces_import_failures_without_crashing_safemode(monkeypatch,capsys):
    import app
    import sys
    import types
    from contextlib import nullcontext
    records=[]
    fake=types.SimpleNamespace(session_state={'ar1981_mode':'full'},
         set_page_config=lambda **kw:records.append(('page_config',kw)),
         sidebar=nullcontext(),
         error=lambda s:records.append(('error',s)),
         warning=lambda s:records.append(('warning',s)),
         caption=lambda s:records.append(('caption',s)),
         button=lambda *a,**k:False)
    monkeypatch.setitem(sys.modules,'streamlit',fake)
    bad=types.ModuleType('v19_ui')
    def fail(**kw):raise ValueError('intentional synthetic error')
    bad.main=fail
    monkeypatch.setitem(sys.modules,'v19_ui',bad)
    app.run()
    assert any(t=='error' for t,_ in records)
    assert 'stage=FULL_DASHBOARD_ERROR' in capsys.readouterr().err
    assert len([t for t,_ in records if t=='page_config'])==1


def test_full_boot_page_config_is_only_called_once(monkeypatch):
    import app,sys,types
    from contextlib import nullcontext
    events=[]
    fake=types.SimpleNamespace(session_state={'ar1981_mode':'full'},
      set_page_config=lambda **kw:events.append('config'),
      sidebar=nullcontext(),button=lambda *a,**kw:False)
    monkeypatch.setitem(sys.modules,'streamlit',fake)
    stub=types.ModuleType('v19_ui')
    def fake_main(configure_page=True):
        assert configure_page is False
        events.append('main')
    stub.main=fake_main
    monkeypatch.setitem(sys.modules,'v19_ui',stub)
    app.run()
    assert events==['config','main']


def test_cloud_probe_can_report_subprocess_failure_without_app_crash(monkeypatch):
    import app,subprocess
    def bad(*args,**kwargs):
        return subprocess.CompletedProcess(args,137,stdout='',stderr='Killed')
    monkeypatch.setattr(subprocess,'run',bad)
    outcome=app.run_import_probe()
    assert outcome['status']=='IMPORT_ERROR'
    assert outcome['exit_code']==137


def test_cloud_recent_history_limits_rows_but_full_history_unchanged(tmp_path):
    from v19_service import _recent_price_rows,load_inputs
    from v19_config import Settings
    days=pd.bdate_range('2024-01-01',periods=410)
    data=pd.concat([
        pd.DataFrame({'ticker':ticker,'date':days,'close':np.arange(len(days))})
        for ticker in ('2330.TW','3008.TW','0050.TW')
    ],ignore_index=True)
    # Mix ticker/date order so last K means latest DATE, not the last CSV rows.
    data=data.sample(frac=1.,random_state=34)
    f=tmp_path/'history_prices.csv.gz'
    data.to_csv(f,index=False,compression='gzip')
    recent=_recent_price_rows(f,300,cutoff='2025-05-01')
    assert recent.groupby('ticker').size().to_dict()=={'0050.TW':300,'2330.TW':300,'3008.TW':300}
    assert str(recent.date.max())<='2025-05-01'
    cfg=Settings(stocks=600,as_of='2025-05-01')
    full,_=load_inputs(tmp_path,cfg)
    truncated,_=load_inputs(tmp_path,cfg,recent_bars=300)
    assert len(full)==1230
    assert len(truncated)==900
    assert truncated.groupby('ticker').date.max().equals(full.groupby('ticker').date.max()) is False or len(truncated)<len(full)



def test_lab_ranking_missing_selected_input_excludes_stock():
    from research_lab import DateMatrix, Trial
    n=205
    dt=pd.bdate_range('2025-01-01',periods=n)
    rows=[]
    for i,d in enumerate(dt):
        for code in ['001.TW','002.TW','003.TW','0050.TW']:
            rows.append(dict(date=d,ticker=code,eligible=code!='0050.TW',
                p197_annual_high=np.nan if code=='003.TW' else 90+i*.001,
                p197_downside=90. if code=='003.TW' else 30.,
                net_5=.03 if code=='003.TW' else .01,mae_5=-.01,
                return_basis_5='ADJUSTED_PROVIDER',exit_date_5=d+pd.Timedelta(days=7)))
    p=pd.DataFrame(rows)
    m=DateMatrix(p,['p197_annual_high','p197_downside'],[5],top_k=2)
    z=m.evaluate(Trial(5,{'p197_annual_high':1.},'test'))
    selected=set(np.array(m.tickers)[z['selected'][0]])
    assert selected == {'001.TW','002.TW'}
    assert z['valid'][0]
    assert z['returns'][0] == pytest.approx(.01)


def test_lab_factor_weights_must_sum_and_no_automatic_live():
    from research_lab import Trial,selection_score,protocol_key
    p={'coverage':1.,'n_dates':50,'nonoverlap':10,'excess_mean':.02,
       'excess_std':.01,'downside_mean':-.02}
    assert np.isfinite(selection_score(p,2))
    assert selection_score({**p,'nonoverlap':2},2) == -np.inf
    assert protocol_key('hash',['factor'],[5],1981,3) != protocol_key('other',['factor'],[5],1981,3)


def test_lab_unbounded_restart_and_one_time_seal(tmp_path):
    from research_lab import DateMatrix, optimise, Trial
    from types import SimpleNamespace
    dates=pd.bdate_range('2024-03-01',periods=350)
    panel=[]
    for i,d in enumerate(dates):
        for code in ('001.TW','002.TW','003.TW','0050.TW'):
            panel.append(dict(date=d,ticker=code,eligible=code!='0050.TW',
                p197_annual_high=float(40 + i*.03 + (code=='001.TW')),
                p197_downside=float(60+i*.01 + (code=='002.TW')),
                net_5=.004 if code=='0050.TW' else .005 + (.001 if code=='001.TW' else 0),
                mae_5=-.02,return_basis_5='ADJUSTED_PROVIDER',
                exit_date_5=d+pd.Timedelta(days=7)))
    matrix=DateMatrix(pd.DataFrame(panel),['p197_annual_high','p197_downside'],[5],top_k=2)
    args=SimpleNamespace(output=str(tmp_path),seed=1981,horizons=[5],max_inputs=2,
        reset=False,resume=False,finalize=False,include_optional=False,rounds=0,batch=4,patience=2,
        max_minutes=.5,min_progress=.00015)
    first=optimise(args,matrix,'abc')
    assert first['audit_exposed'] is False
    assert not (tmp_path/'frozen_models.json').exists()
    assert (tmp_path/'checkpoint.json').exists()
    args.resume=True
    args.finalize=True
    second=optimise(args,matrix,'abc')
    assert second['audit_exposed'] is True
    assert (tmp_path/'sealed.json').exists()
    assert json.loads((tmp_path/'frozen_models.json').read_text())['sealed']
    assert not second['results']['5']['independent_approval']
    with pytest.raises(ValueError,match='sealed'):
        optimise(args,matrix,'abc')


def test_cloud_database_download_is_explicit_not_eager(tmp_path,monkeypatch):
    """A large archive must never be read merely to render the Cloud homepage."""
    import sys,types
    from v192_ui import database_download
    p=tmp_path/'v192_history_database.zip';p.write_bytes(b'test archive payload')
    calls=[]
    fake=types.SimpleNamespace(
        session_state={},
        button=lambda *a,**k:calls.append('prepare_button') or False,
        download_button=lambda *a,**k:calls.append(('download',a[1]))
    )
    monkeypatch.setitem(sys.modules,'streamlit',fake)
    database_download(tmp_path)
    assert calls==['prepare_button']
    fake.button=lambda *a,**k:True
    database_download(tmp_path)
    assert calls[-1]==('download',b'test archive payload')


def test_cloud_locked_streamlit_skips_known_buggy_1580():
    from pathlib import Path
    requirements=Path(__file__).parent.joinpath('requirements.txt').read_text()
    assert 'streamlit==1.59.2' in requirements
    assert 'pyarrow==24.0.0' in requirements

# V19.8.3a hotfix: FinMind TaiwanStockInfo 402 must not block a staged run
# when the official TWSE/TPEx current company masters are available.
def test_finmind_402_falls_back_to_official_twse_tpex_master(tmp_path, monkeypatch):
    import market_data
    rows=catalog(120)
    official=pd.DataFrame([{'ticker':r['ticker'],'name':r['name'],'industry':r['sector']} for r in rows])
    def denied(*args, **kwargs):
        raise SourceError('FinMind permission or rate limit: 402')
    monkeypatch.setattr(Client,'finmind',denied)
    monkeypatch.setattr(market_data,'fetch_twse_universe',lambda *a,**k:official.copy())
    events=[]
    pool,scope=Client(tmp_path,Settings(stocks=40,universe_mode='balanced')).universe(
        progress=lambda stage,done,total,msg:events.append((stage,done,total,msg)))
    assert len(pool)==40
    assert 'TWSE_TPEX_OFFICIAL_CURRENT_SNAPSHOT' in scope
    assert any(stage=='universe' and done==2 for stage,done,_,_ in events)
    assert any(stage=='universe' and done==3 for stage,done,_,_ in events)
    saved=json.loads((tmp_path/'universe.json').read_text())
    assert len(saved['rows'])==120


def test_download_history_reports_universe_before_prices(tmp_path, monkeypatch):
    rows=catalog(40)
    atomic_json(tmp_path/'universe.json',{'at':time.time(),'rows':rows,'scope':'CACHED_CURRENT_SNAPSHOT'})
    def fake_prices(self,ticker,start,end,official_fallback=False,force=False):
        dates=pd.bdate_range('2025-01-01',periods=90)
        vals=np.linspace(10,20,len(dates))
        x=pd.DataFrame({'date':dates,'ticker':ticker,'open':vals,'high':vals*1.01,
          'low':vals*.99,'close':vals,'volume':1000000,'adj_close':vals,'source':'MOCK'})
        return x,{'ticker':ticker,'state':'FETCHED','rows':len(x)}
    monkeypatch.setattr(Client,'prices',fake_prices)
    events=[]
    download_history(tmp_path,Settings(stocks=40,as_of='2025-06-30',download_batch_size=15),
                     progress=lambda *x:events.append(x))
    assert events[0][0]=='universe'
    assert any(x[0]=='download' for x in events)

# V19.8.6: frozen candidate and prospective-governance checks.
def test_v1986_frozen_candidate_weights_are_low_dimensional_and_not_auto_promoted(monkeypatch):
    import v197_selection
    from v198_selection import FREEZE_DATE, HORIZON_GOVERNANCE, fit_before, optimized_anchor
    assert optimized_anchor(5)=={'p197_annual_high':1.0}
    assert optimized_anchor(20)=={'p197_annual_high':1.0}
    assert optimized_anchor(60)=={'p197_liquidity':.70,'p197_annual_high':.30}
    assert HORIZON_GOVERNANCE[5]=='EXPERIMENTAL_FORWARD_TRACKING'
    def fake_fit(panel,cutoff,h,cfg,seed,context):
        return {'trend':1.0},{'selected_profile':'legacy_control','status':'CONTROL','allocation_allowed':False},[]
    monkeypatch.setattr(v197_selection,'fit_before',fake_fit)
    before=pd.Timestamp(FREEZE_DATE)-pd.Timedelta(days=1)
    w0,i0,_=fit_before(None,before,20,Settings(),1,None)
    assert w0=={'trend':1.0} and not i0.get('v1986_forward_candidate',False)
    from v20_model import V20_FREEZE_DATE
    w,i,trace=fit_before(None,pd.Timestamp(V20_FREEZE_DATE),20,Settings(),1,None)
    from v20_model import v20_anchor
    assert w==v20_anchor(20)
    assert i['status']=='V202_CORE_FIRST_FORWARD_CANDIDATE'
    assert i['v20_forward_candidate'] and i['v1986_forward_candidate'] and not i['allocation_allowed']
    assert i['allocation_reason']=='V202_RESEARCH_RANKING_MANUAL_REVIEW_ONLY'
    assert i['v20_layer'].startswith('Next Compounder')
    assert trace[-1]['automatic_orders_authorized'] is False


def test_v1986_s7_excludes_exact_s6_development_cutoffs():
    from v192_sampling import cutoff_plan
    from v1983_stages import apply_stage
    from v198_selection import DEVELOPMENT_CUTOFFS
    cal=pd.bdate_range('2024-01-02','2026-12-31')
    tickers=[f'{2000+i}.TW' for i in range(20)]
    panel=pd.DataFrame([(d,t,True) for d in cal for t in tickers],columns=['date','ticker','eligible'])
    cfg=apply_stage(Settings(warmup=80,train_dates=35,horizons=(5,20,60),min_universe=10),'S7')
    dates,info=cutoff_plan(panel,cal,cfg)
    selected={str(d.date()) for d in dates}
    assert len(dates)==24 and info['method']=='stratified'
    assert not (selected & set(DEVELOPMENT_CUTOFFS))
    assert set(info['excluded_development_cutoffs']).issubset(set(DEVELOPMENT_CUTOFFS))


def test_v1986_s7_confirmation_gate_never_relabels_historical_crosscheck_as_future_holdout():
    from v198_selection import DEVELOPMENT_CUTOFFS, optimized_audit
    dates=[str(d.date()) for d in pd.bdate_range('2024-01-03',periods=12)]
    assert not (set(dates) & set(DEVELOPMENT_CUTOFFS))
    results=[]
    for h,strategy in ((5,'ten_shadow_high_52'),(20,'ten_shadow_high_52'),(60,'ten_shadow_liquid_high_70_30')):
        for i,d in enumerate(dates):
            # Vary positive excess so bootstrap/LOO/halves remain meaningful.
            cand=.015+.001*(i%4)
            results += [
                {'date':d,'horizon':h,'strategy':strategy,'complete':True,'mean_net':cand,'price_basis':'ADJ'},
                {'date':d,'horizon':h,'strategy':'benchmark_0050','complete':True,'mean_net':0.0,'price_basis':'ADJ'},
            ]
    report={'settings':{'research_stage':'S7'},'cutoffs':dates,'results':results}
    audit=optimized_audit(report,bootstrap_reps=1000)
    assert audit['status']=='S7_HISTORICAL_CROSSCHECK_PASS_NOT_FUTURE_HOLDOUT'
    assert audit['confirmation_gate']['core_crosscheck_pass']
    assert audit['new_holdout'] is False and not audit['confirmation_gate']['is_independent_future_holdout']
    report['cutoffs']=[DEVELOPMENT_CUTOFFS[0],*dates[1:]]
    audit2=optimized_audit(report,bootstrap_reps=1000)
    assert audit2['status']=='S7_HISTORICAL_CROSSCHECK_NOT_CONFIRMED'
    assert audit2['confirmation_gate']['cutoff_overlap_count']==1


# V19.8.7: S8 does not rescue rejected S7 horizons or reuse exposed dates.
def test_v1987_s8_uses_new_universe_seed_and_excludes_s7_dates():
    from v192_sampling import cutoff_plan
    from v1983_stages import apply_stage
    from v198_selection import EXPOSED_CUTOFFS_THROUGH_S7
    cal=pd.bdate_range('2024-01-02','2026-12-31')
    tickers=[f'{3000+i}.TW' for i in range(30)]
    panel=pd.DataFrame([(d,t,True) for d in cal for t in tickers],columns=['date','ticker','eligible'])
    cfg=apply_stage(Settings(warmup=80,train_dates=35,horizons=(5,20,60),min_universe=10),'S8')
    dates,info=cutoff_plan(panel,cal,cfg)
    selected={str(d.date()) for d in dates}
    assert len(dates)==24 and cfg.universe_seed==161803 and cfg.seed==314159
    assert not (selected & set(EXPOSED_CUTOFFS_THROUGH_S7))
    assert set(info['excluded_development_cutoffs']).issubset(set(EXPOSED_CUTOFFS_THROUGH_S7))


def test_v1987_s8_new_relative_profiles_are_diagnostic_only():
    from v198_selection import diagnostic_profiles_v1987, profiles_for_v198
    c7=Settings(research_stage='S7')
    c8=Settings(research_stage='S8')
    assert diagnostic_profiles_v1987(20,c7)=={}
    d=diagnostic_profiles_v1987(20,c8)
    assert d['s8_relative_only']=={'p197_relative':1.0}
    assert d['s8_high_relative_50_50']=={'p197_annual_high':.5,'p197_relative':.5}
    assert all(abs(sum(w.values())-1)<1e-12 for w in d.values())
    # The prequential tournament family is unchanged; S8 additions are shadow-only.
    assert not any(k.startswith('s8_') for k in profiles_for_v198(20,c8))


def test_v1987_s8_gate_only_can_confirm_60d_and_never_calls_it_future_holdout():
    from v198_selection import EXPOSED_CUTOFFS_THROUGH_S7, optimized_audit
    dates=[]
    for year in (2024,2025,2026):
        for d in pd.bdate_range(f'{year}-01-03',periods=12):
            ds=str(d.date())
            if ds not in EXPOSED_CUTOFFS_THROUGH_S7: dates.append(ds)
            if len([x for x in dates if x.startswith(str(year))])==8: break
    assert len(dates)==24
    results=[]
    for h,strategy in ((5,'ten_shadow_high_52'),(20,'ten_shadow_high_52'),(60,'ten_shadow_liquid_high_70_30')):
        for i,d in enumerate(dates):
            # 60d is robustly positive vs benchmark, legacy and broad universe;
            # 5/20 are deliberately positive too but are not eligible for S8 rescue.
            cand=.05 + .002*(i%3) if h==60 else .02
            bm=0.0; legacy=.01 if h==60 else .0; uni=.015 if h==60 else .0
            results += [
                {'date':d,'horizon':h,'strategy':strategy,'complete':True,'mean_net':cand,'price_basis':'ADJ','mean_mae':-.01,'mean_position_mdd':-.02},
                {'date':d,'horizon':h,'strategy':'benchmark_0050','complete':True,'mean_net':bm,'price_basis':'ADJ'},
                {'date':d,'horizon':h,'strategy':'baseline','complete':True,'mean_net':legacy,'price_basis':'ADJ'},
                {'date':d,'horizon':h,'strategy':'equal_weight_universe','complete':True,'mean_net':uni},
                {'date':d,'horizon':h,'strategy':'ten_market_cash_RESEARCH_ONLY','complete':True,'mean_net':cand,'price_basis':'ADJ','case_reason':'SUPPORTIVE_OR_NEUTRAL_RESEARCH_RISK_POLICY'},
            ]
    report={'settings':{'research_stage':'S8'},'cutoffs':dates,'results':results}
    audit=optimized_audit(report,bootstrap_reps=1200)
    gate=audit['confirmation_gate']
    assert audit['status']=='S8_60D_CROSS_UNIVERSE_PASS_NOT_FUTURE_HOLDOUT'
    assert gate['checks']['60'] is True and gate['checks']['20'] is False and gate['checks']['5'] is False
    assert gate['rejected_horizons_not_eligible_for_s8_rescue']==[5,20]
    assert audit['new_holdout'] is False and gate['is_independent_future_holdout'] is False
