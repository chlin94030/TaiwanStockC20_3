"""V20.2.1 core-first regression tests. Synthetic fixtures are engineering checks only."""
import numpy as np
import pandas as pd
import pytest

from v20_model import (
    LIVE_ANCHORS, CORE_SLEEVES, HIERARCHY_WEIGHTS, V20_VERSION,
    audit_v20_report, audit_v202_report, build_layer_scores, build_v202_scores,
    entry_state, evidence_summary, summarize_auto_campaign, summarize_v202_campaign,
    v20_anchor, v20_profile_name, add_v202_factors, rank_v202_day, v202_market_state,
)
from v1983_stages import AUTO_WAVES, apply_stage, get_stage, next_stage_key
from v19_config import Settings, VERSION


def test_v202_version_and_core_first_anchors():
    assert V20_VERSION == VERSION == '20.3-final'
    for h,w in LIVE_ANCHORS.items():
        assert sum(w.values()) == pytest.approx(1.)
        assert w == {'p197_liquidity':.80,'p197_annual_high':.20}
        assert v20_anchor(h)==w
        assert v20_profile_name(h).startswith('v202_')
    assert sum(HIERARCHY_WEIGHTS.values()) == pytest.approx(1.)


def test_core_sleeves_are_legacy_40_60_and_live_core_is_separate_80_20():
    cap=CORE_SLEEVES['capacity'];lead=CORE_SLEEVES['leader']
    assert cap['allocation']==pytest.approx(.40)
    assert lead['allocation']==pytest.approx(.60)
    liq=cap['allocation']+lead['allocation']*.70
    high=lead['allocation']*.30
    assert liq==pytest.approx(.82)
    assert high==pytest.approx(.18)
    assert v20_anchor(60)=={'p197_liquidity':.80,'p197_annual_high':.20}


def test_horizon_matched_relative_factors_and_core_scores():
    dates=pd.to_datetime(['2026-01-01']*4)
    p=pd.DataFrame({
        'date':dates,'ticker':['0050.TW','1111.TW','2222.TW','3333.TW'],
        'eligible':[False,True,True,True],
        'ret5':[.02,.06,.01,-.02],'ret20':[.05,.12,.02,-.03],'ret60':[.10,.20,.08,-.01],
        'volume_ratio':[1,2,1,.5],'accumulation':[50,80,50,20],
        'orderly_pullback':[50,70,60,30],'rsi':[60,62,58,85],'bias20':[2,4,6,15],
        'p197_liquidity':[50,90,70,30],'p197_annual_high':[50,80,60,40],
        'p197_downside':[50,70,60,30],'p197_trend_eff':[50,80,70,20],
    })
    cfg=Settings(min_universe=3,stocks=10,dates=2,top_k=3)
    q=add_v202_factors(p,cfg)
    stock=q[q.ticker=='1111.TW'].iloc[0]
    assert stock.p202_rel5>q[q.ticker=='2222.TW'].iloc[0].p202_rel5
    assert stock.p202_rel20>q[q.ticker=='2222.TW'].iloc[0].p202_rel20
    assert q[q.ticker=='3333.TW'].iloc[0].p202_entry_quality < stock.p202_entry_quality
    z=build_v202_scores(q[q.eligible])
    assert 'v202_core' in z and 'v202_confirm' in z and 'v202_timing' in z


def test_core_first_cascade_does_not_let_timing_override_core():
    rows=[]
    for i in range(8):
        rows.append({'date':pd.Timestamp('2026-01-02'),'ticker':f'{1100+i}.TW','eligible':True,
                     'p197_liquidity':100-i*5,'p197_annual_high':90-i*3,
                     'p197_downside':70,'p197_trend_eff':70,
                     'p202_rel20':70,'p202_rel5':90-i,'p202_volume_impulse':80,'p202_entry_quality':80,
                     'bias20':4,'rsi':60})
    day=pd.DataFrame(rows)
    cfg=Settings(stocks=20,dates=2,top_k=5)
    q=rank_v202_day(day,5,cfg)
    assert len(q)==5
    assert q.v202_core.is_monotonic_decreasing
    assert list(q.ticker)==[f'{1100+i}.TW' for i in range(5)]


def test_v202_market_state_separates_index_lead_and_cash():
    base=pd.DataFrame({'eligible':[True]*5,'regime':['BULL']*5,'p197_market_breadth':[.45]*5})
    assert v202_market_state(base)=='INDEX_LEAD'
    base['p197_market_breadth']=.65
    assert v202_market_state(base)=='STOCK_SELECTION'
    base['regime']='BEAR'
    assert v202_market_state(base)=='CASH'


def _line(date,h,strategy,val,case='COMPLETE',basis='ADJUSTED_PROVIDER'):
    return {'date':date,'horizon':h,'strategy':strategy,'mean_net':val,'complete':True,
            'case_reason':case,'price_basis':basis,'path_complete':True,'selected':5,'slots':5,'filled':5}


def test_v20_legacy_audit_remains_readable():
    rows=[]
    for d,bm,cap,lead,gate in [
        ('2025-01-02',.02,.04,.06,'SUPPORTIVE_OR_NEUTRAL_RESEARCH_RISK_POLICY'),
        ('2025-05-02',-.03,.08,.10,'PREDECLARED_MARKET_RISK_CASH'),
    ]:
        rows += [_line(d,60,'benchmark_0050',bm),_line(d,60,'ten_shadow_v20_core_capacity',cap),
                 _line(d,60,'ten_shadow_v20_core_leader_70_30',lead),
                 _line(d,60,'ten_market_cash_RESEARCH_ONLY',0 if 'CASH' in gate else .01,case=gate,basis='CASH' if 'CASH' in gate else 'ADJUSTED_PROVIDER')]
    a=audit_v20_report({'results':rows},bootstrap_reps=2500)
    h60=next(x for x in a['horizons'] if x['horizon']==60)
    assert h60['mean_net']==pytest.approx(.026)
    assert h60['mean_excess']==pytest.approx(.031)


def test_v202_dual_benchmark_audit():
    rows=[]
    for d,c,ew,bm,pol in [('2025-01-02',.06,.02,.04,.06),('2025-02-03',.03,.01,.05,.05)]:
        rows += [_line(d,60,'v202_core_cascade',c),_line(d,60,'equal_weight_universe',ew),
                 _line(d,60,'benchmark_0050',bm),_line(d,60,'v202_policy',pol)]
    a=audit_v202_report({'results':rows},bootstrap_reps=2500)
    h=next(x for x in a['horizons'] if x['horizon']==60)
    assert h['selection_vs_same_pool']['mean']==pytest.approx(.03)
    assert h['selection_vs_0050']['mean']==pytest.approx(0.0)
    assert h['policy_vs_0050']['mean']==pytest.approx(.01)
    assert a['primary_selection_benchmark']=='SAME_POOL_EQUAL_WEIGHT'



def test_c1_cutoff_plan_really_honors_campaign_exclusions():
    from dataclasses import replace
    from v192_sampling import cutoff_plan
    cal=pd.bdate_range('2024-01-02',periods=420)
    tickers=[f'{1100+i}.TW' for i in range(20)]
    panel=pd.DataFrame({'date':np.repeat(cal,len(tickers)),
                        'ticker':tickers*len(cal),'eligible':True})
    cfg=replace(Settings(stocks=150,dates=48,warmup=80,train_dates=35,
                         seed=316227,universe_seed=282843,sampling_method='stratified'),
                research_stage='C1',excluded_cutoffs=())
    first,plan1=cutoff_plan(panel,cal,cfg)
    excluded=tuple(str(x.date()) for x in first[:10])
    second,plan2=cutoff_plan(panel,cal,replace(cfg,excluded_cutoffs=excluded))
    second_text={str(x.date()) for x in second}
    assert second_text.isdisjoint(excluded)
    assert set(excluded).issubset(set(plan2['excluded_development_cutoffs']))
    assert plan2['disjoint_cutoffs']['60']


def test_v202_audit_reports_overlap_controls_and_participation():
    rows=[]
    dates=['2025-01-02','2025-02-03','2025-04-01','2025-07-01']
    for d in dates:
        rows += [_line(d,60,'v202_core_cascade',.06),_line(d,60,'equal_weight_universe',.02),
                 _line(d,60,'benchmark_0050',.04),_line(d,60,'v202_policy',.05)]
    report={'results':rows,'sampling_plan':{'disjoint_cutoffs':{'60':['2025-01-02','2025-04-01']}}}
    a=audit_v202_report(report,bootstrap_reps=2500)
    h=next(x for x in a['horizons'] if x['horizon']==60)
    sel=h['selection_vs_same_pool']
    assert h['cascade_participation_rate']==pytest.approx(1.)
    assert sel['quarter_clusters']>=2
    assert sel['disjoint_cases']==2
    assert sel['disjoint_mean']==pytest.approx(.04)

def test_auto_campaign_is_two_clean_48_date_waves():
    assert next_stage_key('S8') is None
    assert [x['key'] for x in AUTO_WAVES]==['C1','C2']
    assert [x['dates'] for x in AUTO_WAVES]==[48,48]
    assert all(x['stocks']==150 and x['universe_mode']=='proportional' for x in AUTO_WAVES)
    c1=apply_stage(Settings(),'C1')
    assert (c1.stocks,c1.dates,c1.seed,c1.universe_seed)==(150,48,316227,282843)
    assert c1.sampling_method=='stratified' and c1.universe_mode=='proportional'
    assert get_stage('C2')['min_download_coverage']==.92


def test_evidence_summary_is_research_only():
    e=evidence_summary()
    assert e['version']=='20.3-final'
    assert e['automatic_orders_authorized'] is False


def test_v202_campaign_summary_keeps_benchmarks_separate():
    def rep(stage,offset):
        rows=[]
        for i in range(4):
            d=f'2025-0{i+1}-10';c=.05+offset;ew=.02;bm=.04;pol=.04+max(offset,0)
            rows += [_line(d,60,'v202_core_cascade',c),_line(d,60,'equal_weight_universe',ew),
                     _line(d,60,'benchmark_0050',bm),_line(d,60,'v202_policy',pol)]
        return {'version':'20.3-final','final_protocol_hash':__import__('v20_final').protocol_hash(),'settings':{'research_stage':stage},'cutoffs':sorted({r['date'] for r in rows}),'results':rows}
    out=summarize_v202_campaign([rep('C1',.01),rep('C2',.00)])
    h=next(x for x in out['horizons'] if x['horizon']==60)
    assert h['selection_vs_same_pool']['cases']==8
    assert h['selection_vs_same_pool']['mean']>0
    assert h['policy_vs_0050']['mean']>=0
    assert out['automatic_weight_adoption'] is False


def test_auto_campaign_chains_two_waves_without_manual_clicks(tmp_path,monkeypatch):
    import time
    import v19_service as svc
    calls=[];current={'stage':None}
    def fake_start(root,cfg,mode='download_validate',resume=True):
        calls.append((cfg.research_stage,cfg.dates,cfg.seed,cfg.universe_seed,tuple(cfg.excluded_cutoffs),cfg.universe_mode,mode));current['stage']=cfg.research_stage
        return {'started':True,'state':'RUNNING','run_id':'fake-'+cfg.research_stage}
    def fake_status(root):
        if current['stage'] is None: return {'state':'IDLE'}
        return {'run_id':'fake-'+current['stage'],'state':'DONE','message':'ok','stage_gate':{'execution_status':'STAGE_COMPLETE'},'report_directory':str(tmp_path/current['stage']),'overall_pct':1.0}
    def fake_report(root,job):
        stage=current['stage'];base={'C1':1,'C2':3}[stage]
        return {'version':'20.3-final','final_protocol_hash':__import__('v20_final').protocol_hash(),'settings':{'research_stage':stage},'cutoffs':[f'2025-01-{base+i:02d}' for i in range(2)],
                'stage_gate':{'execution_status':'STAGE_COMPLETE','research_status':'RESEARCH_PARTIAL','download_coverage':.95},
                'v202_audit':{'horizons':[]},'results':[]}
    monkeypatch.setattr(svc,'start_job',fake_start);monkeypatch.setattr(svc,'job_status',fake_status);monkeypatch.setattr(svc,'_auto_report_from_job',fake_report)
    monkeypatch.setattr(svc,'read_last_report',lambda root:{})
    out=svc.start_auto_campaign(tmp_path,Settings(as_of='2026-10-19'),resume=False)
    assert out['started']
    deadline=time.time()+4;status={}
    while time.time()<deadline:
        status=svc.auto_campaign_status(tmp_path)
        if status.get('state')=='DONE':break
        time.sleep(.02)
    assert status.get('state')=='DONE'
    assert [x[0] for x in calls]==['C1','C2']
    assert [x[1] for x in calls]==[48,48]
    assert calls[0][4]==()
    assert set(calls[1][4])=={'2025-01-01','2025-01-02'}
    assert all(x[5]=='proportional' and x[6]=='download_validate' for x in calls)


def test_v202_clean_wave_rejects_stale_provider_catalog_and_uses_official(tmp_path,monkeypatch):
    import json,time
    import market_data
    from v19_data import Client
    stale={'at':time.time(),'scope':'LATEST_FINMIND_STOCK_INFO_NOT_HISTORICAL_MEMBERSHIP',
           'rows':[{'ticker':'9999.TW','name':'stale','sector':'OLD'}]}
    (tmp_path/'universe.json').write_text(json.dumps(stale),encoding='utf-8')
    official=pd.DataFrame([{'ticker':f'{1101+i}.TW','name':f'N{i}','industry':'S'} for i in range(8)])
    monkeypatch.setattr(market_data,'fetch_twse_universe',lambda **kwargs:official)
    cfg=Settings(stocks=5,dates=2,research_stage='C1',universe_mode='proportional')
    selected,scope=Client(tmp_path,cfg).universe()
    assert scope.startswith('V202_TWSE_TPEX_OFFICIAL_CURRENT')
    assert '9999.TW' not in {x['ticker'] for x in selected}
    assert len(selected)==5


def test_v202_campaign_excludes_all_saved_exposed_cutoffs(tmp_path,monkeypatch):
    import json,time
    import v19_service as svc
    runroot=tmp_path/'runs';runroot.mkdir(parents=True)
    for name,stage,dates in [
        ('old_s7','S7',['2025-01-03','2025-02-04']),
        ('old_s8','S8',['2025-03-05']),
        ('old_a3','A3',['2025-04-06']),
    ]:
        d=runroot/name;d.mkdir()
        (d/'v19_results.json').write_text(json.dumps({
            'settings':{'research_stage':stage,'excluded_cutoffs':[]},
            'cutoffs':dates,'stage_gate':{'stage':stage,'execution_status':'STAGE_COMPLETE'},
        }),encoding='utf-8')
    monkeypatch.setattr(svc,'read_last_report',lambda root:{})
    calls=[];cur={'stage':None}
    def fake_start(root,cfg,mode='download_validate',resume=True):
        calls.append((cfg.research_stage,set(cfg.excluded_cutoffs)));cur['stage']=cfg.research_stage
        return {'started':True,'state':'RUNNING','run_id':'x'}
    def fake_status(root):
        if cur['stage'] is None: return {'state':'IDLE'}
        return {'run_id':'x','state':'DONE','message':'ok','stage_gate':{'execution_status':'STAGE_COMPLETE'},
                'report_directory':str(tmp_path/('new_'+cur['stage'])),'overall_pct':1.0}
    def fake_report(root,job):
        stage=cur['stage'];dates={'C1':['2025-05-07'],'C2':['2025-06-08']}[stage]
        return {'version':'20.3-final','final_protocol_hash':__import__('v20_final').protocol_hash(),'settings':{'research_stage':stage},'cutoffs':dates,
                'stage_gate':{'execution_status':'STAGE_COMPLETE','research_status':'RESEARCH_PARTIAL','download_coverage':.95},
                'v202_audit':{'horizons':[]},'results':[]}
    monkeypatch.setattr(svc,'start_job',fake_start);monkeypatch.setattr(svc,'job_status',fake_status);monkeypatch.setattr(svc,'_auto_report_from_job',fake_report)
    out=svc.start_auto_campaign(tmp_path,Settings(as_of='2026-10-19'),resume=False);assert out['started']
    deadline=time.time()+4
    while time.time()<deadline:
        status=svc.auto_campaign_status(tmp_path)
        if status.get('state')=='DONE':break
        time.sleep(.02)
    assert status.get('state')=='DONE'
    old={'2025-01-03','2025-02-04','2025-03-05','2025-04-06'}
    assert old.issubset(calls[0][1])
    assert old|{'2025-05-07'} <= calls[1][1]
